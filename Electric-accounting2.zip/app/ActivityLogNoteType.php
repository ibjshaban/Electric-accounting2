<?php

namespace App;

class ActivityLogNoteType
{
    const supplier_payments = 1;
    const salaries = 2;
    const expenses = 3;
    const other_operation = 4;
    const debt = 5;
    const startup = 6;
    const heavy_expenses = 7;
    const rentals = 8;
    const other_notebook = 9;
    const withdrawals = 10;
    const payments = 11;
    const collection = 12;
    const other_collection = 13;
    const generalrevenue = 14;

}
